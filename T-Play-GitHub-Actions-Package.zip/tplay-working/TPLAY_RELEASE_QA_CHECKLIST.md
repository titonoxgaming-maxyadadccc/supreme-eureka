# TITONOX PLAYER — release QA checklist

This source bundle includes the latest requested branding and UI changes. It is not a claim that every device has been runtime-tested.

## Updated in this pass
- About screen identifies the creator as Aditya Yadav and links to TITONOX OFFICIAL YouTube and Instagram.
- App label and adaptive launcher icon use TITONOX PLAYER branding.
- Scrollable Home/Library/Discovery content and Settings pages use a vertical edge mask so text fades into the dark background at the top and bottom.
- Liquid Glass dock now inherits the preference-backed GlassEffectConfig from the activity, so Appearance sliders are not overridden by hard-coded dock values.

## Existing playback features to verify on a real device
- YouTube Music search, song open, queue, play/pause/next/previous.
- Playback when the app is backgrounded; notification and lock-screen actions.
- Lyrics: synchronized LRC where supplied; fall back to fixed lyrics when sync data is unavailable.
- Speed and pitch controls during playback.
- Bass/reverb controls during playback; availability depends on the Android device audio-effect implementation.
- Equalizer controls: built-in band controls appear only when the platform exposes an Equalizer effect/session; otherwise the app shows a device-support explanation.
- Font import with valid TTF and OTF files; remove font and restart verification.
- Glass blur, vibrancy, opacity, lens and adaptive accent settings.
- Bottom dock tap, long-press reorder, saved order after restart.

## Known limitations to test/communicate
- Audio-effect implementations and supported bands vary by device/ROM. The UI must not imply a missing system effect is available.
- Timed lyrics are line-synchronized when the source provides timestamps; word-by-word karaoke timing is not guaranteed.
- Launcher icon/label changes are applied at install/update; some launchers may cache the old icon until refreshed.
- A release is not bug-free until the debug/release variants compile and the above flows are exercised on physical devices.


## New 1.4.0 flows to test on a real device
- Open Library → Local files. First access must ask for READ_MEDIA_AUDIO (Android 13+) or READ_EXTERNAL_STORAGE (Android 12L and older).
- Grant permission and confirm indexed audio appears; deny permission and confirm the page remains usable and offers the permission action.
- Tap a local song and verify it plays through the app without calling the YouTube resolver.
- Long-press a local song; verify copy starts immediately, shows a per-row progress indicator, and appears in Library → Downloads.
- Confirm the private copy is under the app's own files directory, not the public Downloads folder.
- Play an offline copy in airplane mode; remove it from Downloads and verify the original device file remains.
- With a queue of at least two supported tracks, verify crossfade starts 2–6 seconds before the current track ends (4 seconds by default).
- Toggle Crossfade OFF during playback; verify the secondary player stops and main volume returns to its previous level.
- Pause, seek, skip, shuffle, repeat, and edit the queue during a transition; confirm no doubled audio or stuck volume.
- Verify speed/pitch, Bass Boost, Reverb and Equalizer settings remain consistent during the overlap.


## Part 2 visual checks
- [ ] Open a playlist with green/purple cover art; confirm accent changes after cover loads.
- [ ] Open an artist profile with a different cover; confirm accent updates again.
- [ ] Appearance → Dynamic color: test Artwork, Violet, Blue, Rose, Emerald.
- [ ] Appearance → Liquid Glass: test Fastest, Balanced, Quality and then adjust each manual slider.
- [ ] Search tabs: horizontally scroll all categories; switch in both directions and confirm no clipped/vanishing rows.
- [ ] Confirm playlist/artist navigation and player remain functional after accent changes.
