# TITONOX PLAYER 1.5.1 - Part 3 stability audit

## Status
Static source audit only. The project was NOT compiled and NOT run on a device in this environment (no Android SDK, no network access to download Gradle). A real build on GitHub Actions or Android Studio is still required.

## Compile-blocking errors fixed (confirmed by real GitHub Actions compiler output earlier)
- innertube `Discovery.kt`: nullable `titleRun.text` -> `titleRun?.text`; explicit `buildList<Innertube.DiscoveryEntry>`; songs without a videoId are skipped instead of crashing de-duplication.
- `Player.kt`: missing `fillMaxSize` import.
- `PlayerScaffold.kt`: `glassBackdrop` is now `LayerBackdrop` (required by `layerBackdrop(...)`).
- `DiscoveryScreens.kt`: missing `forcePlayFromBeginning` import.

## Found during this audit
- `AppearanceSettings.kt` (Part 2): `horizontalScroll` was imported from the wrong package (`foundation.layout`); corrected to `androidx.compose.foundation.horizontalScroll`.

## Stability / performance
- Album-art accent sampling now has a small in-memory cache, so the mini player, full player, artist page and playlist page do not download and decode the same artwork repeatedly.
- Local device music is now sorted in Kotlin instead of passing a raw `COLLATE NOCASE` string to MediaStore (some Android versions reject unusual sort strings, which would have shown an empty library).

## GitHub readiness
- `.github/workflows/build-apk.yml`: uses the platform package that actually exists (`platforms;android-37.2`), uploads a `build-log` artifact, and prints compiler errors on failure.
- `.gitignore`: now also excludes `**/build/`, APK/AAB files, keystores and logs.
- Version bumped to 1.5.1 (versionCode 23).
- Secret scan: no keystores, tokens or private keys found. The `AIza...` string in innertube is the public YouTube Music web client key used by the upstream project, not a private credential.

## Checks that did run (static scripts)
All Kotlin brackets balanced; every `R.*` reference and every `@resource` reference resolves; manifest classes exist; project imports resolve; no unknown `libs.*` aliases; resource XML parses; no duplicate names, unescaped apostrophes or non-positional multi-argument format strings in any `strings.xml`.

## Known limitations (not changed)
- Local/offline tracks currently show no cover art (no embedded-art extraction).
- Local files pass through the shared audio cache layer, so playing them also fills the app cache; harmless, but uses extra storage until evicted.
- Crossfade, equalizer, bass boost and reverb need a physical device test; effects depend on device audio-effect support.
- Search category slide transitions are not implemented (see Part 2 notes).
- YouTube Music items remain online streams; the private download flow only copies audio files already on the device.
