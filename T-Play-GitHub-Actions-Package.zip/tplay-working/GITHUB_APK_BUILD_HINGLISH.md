# TITONOX PLAYER — APK build guide

## 1. Extract the ZIP

Extract this package. Open the `tplay-working` folder. Its contents are the Android project root: `app/`, `gradle/`, `gradlew`, `settings.gradle.kts`, and `.github/`.

## 2. Build with Android Studio

1. Install Android Studio and JDK 21.
2. Open the `tplay-working` folder as a project.
3. Allow Gradle sync and Android SDK downloads to finish.
4. Select the `app` run configuration and choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. The debug APK will be under `app/build/outputs/apk/debug/`.

## 3. Build using the included cloud workflow

Upload the contents of `tplay-working` to the root of a repository you control. Make sure the hidden `.github/workflows/build-apk.yml` file is uploaded too. Open the repository's **Actions** tab, choose **TITONOX PLAYER Android APK**, and run the workflow on the `main` branch. Download the `TITONOX-PLAYER-debug-apk` artifact from a successful run.

## 3b. Phone-friendly mode: upload the ZIP only

Hundreds of files cannot be uploaded from a phone browser (GitHub allows about 100 files at a time). Instead:

1. Keep the delivered file named exactly `T-Play-GitHub-Actions-Package.zip` and upload only that ZIP to the repository root (**Add file > Upload files**).
2. Create `.github/workflows/build-apk.yml` with **Add file > Create new file** and paste the ZIP-mode workflow (it unzips the package inside GitHub Actions and builds it).
3. Run the workflow from the **Actions** tab. Download `T-Play-debug-apk` (or `TITONOX-PLAYER-debug-apk`) from **Artifacts**. A `build-log` artifact is always uploaded, so any failure can be diagnosed.

The workflow in this project (`.github/workflows/build-apk.yml`) is the normal mode for a repository that contains the extracted project at its root. Do not keep both versions under the same file name in one repository.

## 4. Important notes

- The workflow produces a debug APK, not a Play Store release-signed APK.
- A successful build is not yet a device-compatibility test. Install it and test YouTube Music search, streaming, background playback, notifications, lyrics, the player effects panel, and settings.
- Bass boost, reverb and the in-app equalizer depend on the Android device's audio-effect support. Unsupported effects are guarded so playback can continue.
- Keep all included license and third-party notice files when redistributing the project.
