package com.github.musicyou.ui.screens.player

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AssistChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.github.musicyou.R
import com.github.musicyou.LocalPlayerServiceBinder
import com.github.musicyou.utils.audioEffectsEnabledKey
import com.github.musicyou.utils.bassBoostKey
import com.github.musicyou.utils.playbackPitchKey
import com.github.musicyou.utils.playbackSpeedKey
import com.github.musicyou.utils.rememberPreference
import com.github.musicyou.utils.reverbLevelKey

@Composable
fun EffectsBottomSheet(onDismiss: () -> Unit) {
    val binder = LocalPlayerServiceBinder.current
    var effectsEnabled by rememberPreference(audioEffectsEnabledKey, true)
    var speed by rememberPreference(playbackSpeedKey, 1f)
    var pitch by rememberPreference(playbackPitchKey, 1f)
    var bass by rememberPreference(bassBoostKey, 0)
    var reverb by rememberPreference(reverbLevelKey, 0)

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState())
                .padding(horizontal = 22.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(stringResource(R.string.effects), style = MaterialTheme.typography.headlineSmall)
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Text(stringResource(R.string.effects_enabled), modifier = Modifier.weight(1f))
                Switch(checked = effectsEnabled, onCheckedChange = { effectsEnabled = it })
            }
            Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AssistChip(onClick = { speed = 1f; pitch = 1f; bass = 0; reverb = 0 }, label = { Text(stringResource(R.string.original)) })
                AssistChip(onClick = { speed = 0.85f; pitch = 1f; bass = 18; reverb = 55; effectsEnabled = true }, label = { Text(stringResource(R.string.slowed_reverb)) })
                AssistChip(onClick = { speed = 1.25f; pitch = 1f; bass = 10; reverb = 0; effectsEnabled = true }, label = { Text(stringResource(R.string.speed_up)) })
            }
            EffectSlider("Speed", "%.2f×".format(speed), speed, 0.5f..2f, { speed = it })
            EffectSlider("Pitch", "%.2f×".format(pitch), pitch, 0.7f..1.3f, { pitch = it })
            EffectSlider(stringResource(R.string.bass_boost), "$bass%", bass.toFloat(), 0f..100f, { bass = it.toInt() })
            EffectSlider(stringResource(R.string.reverb), "$reverb%", reverb.toFloat(), 0f..100f, { reverb = it.toInt() })

            val bandCount = binder?.equalizerBandCount() ?: 0
            val bandRange = binder?.equalizerBandRange()
            val bandLevels = remember(binder, bandCount) {
                mutableStateListOf<Int>().apply {
                    repeat(bandCount) { index -> add(binder?.equalizerBandLevel(index) ?: 0) }
                }
            }
            if (bandCount > 0 && bandRange != null) {
                Text("Equalizer", style = MaterialTheme.typography.titleMedium)
                val presets = remember(binder) { binder?.equalizerPresetNames().orEmpty() }
                if (presets.isNotEmpty()) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        presets.take(6).forEachIndexed { index, preset ->
                            AssistChip(onClick = {
                                binder?.applyEqualizerPreset(index)
                                repeat(bandCount) { band -> bandLevels[band] = binder?.equalizerBandLevel(band) ?: 0 }
                            }, label = { Text(preset) })
                        }
                    }
                }
                repeat(bandCount) { index ->
                    val frequencyMilliHz = binder?.equalizerBandFrequency(index) ?: 0
                    val frequencyHz = frequencyMilliHz / 1000
                    val frequencyLabel = if (frequencyHz >= 1000) "${frequencyHz / 1000} kHz" else "$frequencyHz Hz"
                    EffectSlider(
                        frequencyLabel,
                        "${"%.1f".format(bandLevels[index] / 100f)} dB",
                        bandLevels[index].toFloat(),
                        bandRange.first.toFloat()..bandRange.last.toFloat(),
                    ) { level ->
                        bandLevels[index] = level.toInt()
                        binder?.setEqualizerBandLevel(index, level.toInt())
                    }
                }
            } else {
                Text(
                    "Built-in equalizer is not available on this device. You can still use bass, reverb, speed and pitch controls.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Text(
                stringResource(R.string.audio_effects_device_note),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            TextButton(
                onClick = { speed = 1f; pitch = 1f; bass = 0; reverb = 0; effectsEnabled = true },
                modifier = Modifier.align(Alignment.End)
            ) { Text("Reset") }
        }
    }
}

@Composable
private fun EffectSlider(
    title: String,
    valueLabel: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onValueChange: (Float) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(title, modifier = Modifier.weight(1f), style = MaterialTheme.typography.titleSmall)
            Text(valueLabel, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
        }
        Slider(value = value.coerceIn(range), onValueChange = onValueChange, valueRange = range)
    }
}
