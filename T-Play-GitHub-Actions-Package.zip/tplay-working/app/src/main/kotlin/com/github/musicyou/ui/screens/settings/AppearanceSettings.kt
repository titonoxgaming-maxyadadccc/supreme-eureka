package com.github.musicyou.ui.screens.settings

import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.FontDownload
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.TextButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState as rememberHorizontalScrollState
import com.github.musicyou.LocalPlayerPadding
import com.github.musicyou.R
import com.github.musicyou.ui.styling.CustomFontState
import com.github.musicyou.enums.AlbumAccentMode
import com.github.musicyou.utils.albumAccentModeKey
import com.github.musicyou.utils.customFontPathKey
import com.github.musicyou.utils.glassBlurKey
import com.github.musicyou.utils.glassVibrancyKey
import com.github.musicyou.utils.glassOpacityKey
import com.github.musicyou.utils.glassLensAmountKey
import com.github.musicyou.utils.rememberPreference
import com.github.musicyou.utils.toast
import java.io.File

@Composable
fun AppearanceSettings() {
    val context = LocalContext.current
    val playerPadding = LocalPlayerPadding.current
    var customFontPath by rememberPreference(customFontPathKey, "")
    var glassBlur by rememberPreference(glassBlurKey, 7.5f)
    var glassVibrancy by rememberPreference(glassVibrancyKey, 1.25f)
    var glassOpacity by rememberPreference(glassOpacityKey, 0.22f)
    var glassLensAmount by rememberPreference(glassLensAmountKey, 0.58f)
    var accentMode by rememberPreference(albumAccentModeKey, AlbumAccentMode.Artwork)

    val fontPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching {
                val displayName = context.contentResolver.query(
                    uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null
                )?.use { cursor ->
                    if (cursor.moveToFirst()) cursor.getString(0) else null
                }.orEmpty()
                val extension = displayName.substringAfterLast('.', "").lowercase()
                require(extension == "ttf" || extension == "otf")
                val destination = File(context.filesDir, "tplay-custom-font.$extension")
                context.contentResolver.openInputStream(uri).use { input ->
                    requireNotNull(input) { "Cannot read selected font" }
                    destination.outputStream().use { output -> input.copyTo(output) }
                }
                CustomFontState.load(destination.absolutePath)
                requireNotNull(CustomFontState.fontFamily) { "Unsupported font file" }
                customFontPath = destination.absolutePath
                context.toast(context.getString(R.string.font_applied))
            }.onFailure {
                context.toast(context.getString(R.string.font_file_invalid))
            }
        }
    }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 12.dp)
            .padding(bottom = 16.dp + playerPadding),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        SettingsEntry(
            title = stringResource(R.string.custom_font),
            text = if (customFontPath.isBlank()) stringResource(R.string.custom_font_description)
                else File(customFontPath).name,
            icon = Icons.Outlined.FontDownload,
            onClick = { fontPicker.launch(arrayOf("*/*")) }
        )
        Button(
            onClick = { fontPicker.launch(arrayOf("*/*")) },
            modifier = Modifier.fillMaxWidth()
        ) { Text(stringResource(R.string.choose_font_file)) }
        if (customFontPath.isNotBlank()) {
            OutlinedButton(
                onClick = {
                    File(customFontPath).delete()
                    customFontPath = ""
                    CustomFontState.load("")
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text(stringResource(R.string.remove_custom_font)) }
        }
        Spacer(Modifier.height(8.dp))
        Text(stringResource(R.string.font_preview), style = MaterialTheme.typography.headlineSmall)
        Text(
            "Pack your sound with a typeface that feels like yours.",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            "Supported formats: TTF and OTF. The font is copied into this app's private storage; no font file is uploaded.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(10.dp))
        Text("Dynamic color", style = MaterialTheme.typography.titleLarge)
        Text("Choose whether the app follows the current cover art or a fixed accent.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberHorizontalScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            AlbumAccentMode.values().forEach { mode ->
                FilterChip(selected = accentMode == mode, onClick = { accentMode = mode; com.github.musicyou.ui.styling.AlbumAccentModeState.mode = mode }, label = { Text(mode.name) })
            }
        }
        Text("Liquid Glass", style = MaterialTheme.typography.titleLarge)
        Text("Quick quality presets", style = MaterialTheme.typography.titleSmall)
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = glassBlur <= 3f, onClick = { glassBlur = 2.5f; glassVibrancy = 0.8f; glassOpacity = 0.14f; glassLensAmount = 0.25f }, label = { Text("Fastest") })
            FilterChip(selected = glassBlur in 3.1f..10f, onClick = { glassBlur = 7.5f; glassVibrancy = 1.25f; glassOpacity = 0.22f; glassLensAmount = 0.58f; accentMode = AlbumAccentMode.Artwork; com.github.musicyou.ui.styling.AlbumAccentModeState.mode = AlbumAccentMode.Artwork }, label = { Text("Balanced") })
            FilterChip(selected = glassBlur > 10f, onClick = { glassBlur = 15f; glassVibrancy = 1.55f; glassOpacity = 0.28f; glassLensAmount = 0.82f }, label = { Text("Quality") })
        }
        GlassPreferenceSlider(stringResource(R.string.glass_blur), "${"%.1f".format(glassBlur)}", glassBlur, 0f..18f) { glassBlur = it }
        GlassPreferenceSlider(stringResource(R.string.glass_vibrancy), "${"%.2f".format(glassVibrancy)}", glassVibrancy, 0.5f..1.8f) { glassVibrancy = it }
        GlassPreferenceSlider(stringResource(R.string.glass_opacity), "${(glassOpacity * 100).toInt()}%", glassOpacity, 0.08f..0.45f) { glassOpacity = it }
        GlassPreferenceSlider(stringResource(R.string.glass_lens), "${"%.2f".format(glassLensAmount)}", glassLensAmount, 0.1f..0.9f) { glassLensAmount = it }
        TextButton(
            onClick = { glassBlur = 7.5f; glassVibrancy = 1.25f; glassOpacity = 0.22f; glassLensAmount = 0.58f; accentMode = AlbumAccentMode.Artwork; com.github.musicyou.ui.styling.AlbumAccentModeState.mode = AlbumAccentMode.Artwork },
            modifier = Modifier.align(androidx.compose.ui.Alignment.End)
        ) { Text("Reset glass") }
    }
}


@Composable
private fun GlassPreferenceSlider(
    title: String,
    valueLabel: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onValueChange: (Float) -> Unit
) {
    Column(verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(2.dp)) {
        androidx.compose.foundation.layout.Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            Text(title, modifier = Modifier.weight(1f), style = MaterialTheme.typography.titleSmall)
            Text(valueLabel, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
        }
        Slider(value = value.coerceIn(range), onValueChange = onValueChange, valueRange = range)
    }
}
