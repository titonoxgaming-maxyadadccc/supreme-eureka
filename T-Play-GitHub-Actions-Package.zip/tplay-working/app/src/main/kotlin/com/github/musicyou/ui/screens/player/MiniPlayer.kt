package com.github.musicyou.ui.screens.player

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Clear
import androidx.compose.material.icons.outlined.Pause
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.material.icons.outlined.Replay
import androidx.compose.material.icons.outlined.SkipNext
import androidx.compose.material.icons.outlined.SkipPrevious
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.neverEqualPolicy
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import coil3.compose.AsyncImage
import com.github.musicyou.LocalPlayerServiceBinder
import com.github.musicyou.ui.styling.Dimensions
import com.github.musicyou.ui.styling.AlbumArtworkPalette
import com.github.musicyou.ui.styling.extractAlbumAccent
import com.github.musicyou.ui.styling.px
import com.github.musicyou.utils.DisposableListener
import com.github.musicyou.utils.forceSeekToNext
import com.github.musicyou.utils.forceSeekToPrevious
import com.github.musicyou.utils.miniplayerGesturesEnabledKey
import com.github.musicyou.utils.positionAndDurationState
import com.github.musicyou.utils.rememberPreference
import com.github.musicyou.utils.shouldBePlaying
import com.github.musicyou.utils.thumbnail
import me.saket.swipe.SwipeAction
import me.saket.swipe.SwipeableActionsBox
import kotlin.math.absoluteValue
import dev.lelonio.square.ui.glass.LocalGlassEffectConfig
import dev.lelonio.square.ui.glass.liquidGlass
import dev.lelonio.square.ui.glass.LiquidButton
import dev.lelonio.square.ui.glass.backdrop.Backdrop

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MiniPlayer(
    glassBackdrop: Backdrop,
    openPlayer: () -> Unit,
    stopPlayer: () -> Unit
) {
    val binder = LocalPlayerServiceBinder.current
    binder?.player ?: return

    var miniplayerGesturesEnabled by rememberPreference(miniplayerGesturesEnabledKey, true)
    var shouldBePlaying by remember { mutableStateOf(binder.player.shouldBePlaying) }

    var nullableMediaItem by remember {
        mutableStateOf(binder.player.currentMediaItem, neverEqualPolicy())
    }

    binder.player.DisposableListener {
        object : Player.Listener {
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                nullableMediaItem = mediaItem
            }

            override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) {
                shouldBePlaying = binder.player.shouldBePlaying
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                shouldBePlaying = binder.player.shouldBePlaying
            }
        }
    }

    val mediaItem = nullableMediaItem ?: return
    val context = LocalContext.current
    LaunchedEffect(mediaItem.mediaId, mediaItem.mediaMetadata.artworkUri) {
        val sampledAccent = extractAlbumAccent(context, mediaItem.mediaMetadata.artworkUri)
        AlbumArtworkPalette.update(sampledAccent ?: Color(0xFFB9A4FF))
    }
    val positionAndDuration by binder.player.positionAndDurationState()

    val miniPlayerContent: @Composable BoxScope.() -> Unit = @Composable {
        val glassShape = RoundedCornerShape(27.dp)
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(glassShape)
                .liquidGlass(
                    config = LocalGlassEffectConfig.current.copy(
                        blurRadius = 10f,
                        lensHeight = 0.42f,
                        lensAmount = 0.5f,
                        surfaceTintColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.20f),
                        surfaceOpacity = 0.24f,
                    ),
                    shape = glassShape,
                    blurRadiusDp = 10f,
                    highlightAlpha = 0.30f,
                    ownBackdrop = glassBackdrop,
                )
                .clickable(onClick = openPlayer)
                .padding(start = 9.dp, end = 7.dp, top = 8.dp, bottom = 5.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(9.dp)
            ) {
                AsyncImage(
                    model = mediaItem.mediaMetadata.artworkUri.thumbnail(Dimensions.thumbnails.song.px),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .clip(RoundedCornerShape(17.dp))
                        .size(49.dp)
                )

                Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text(
                        text = mediaItem.mediaMetadata.title?.toString() ?: "",
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        style = MaterialTheme.typography.labelLarge,
                        color = Color(0xFFF8F5FF)
                    )
                    Text(
                        text = mediaItem.mediaMetadata.artist?.toString() ?: "",
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFFBDB6CB)
                    )
                }

                LiquidButton(
                    onClick = { binder.player.forceSeekToNext() },
                    backdrop = glassBackdrop,
                    modifier = Modifier.size(36.dp),
                    shape = CircleShape,
                    contentHeight = 36.dp,
                    contentPadding = 0.dp,
                    surfaceColor = Color.White.copy(alpha = 0.035f),
                ) {
                    Icon(
                        imageVector = Icons.Outlined.SkipNext,
                        contentDescription = "Next track",
                        tint = Color(0xFFF4F0FA),
                        modifier = Modifier.size(21.dp),
                    )
                }

                LiquidButton(
                    onClick = {
                        if (shouldBePlaying) binder.player.pause()
                        else {
                            if (binder.player.playbackState == Player.STATE_IDLE) {
                                binder.player.prepare()
                            } else if (binder.player.playbackState == Player.STATE_ENDED) {
                                binder.player.seekToDefaultPosition(0)
                            }
                            binder.player.play()
                        }
                    },
                    backdrop = glassBackdrop,
                    modifier = Modifier.size(39.dp),
                    shape = CircleShape,
                    contentHeight = 39.dp,
                    contentPadding = 0.dp,
                    surfaceColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.18f),
                ) {
                    Icon(
                        imageVector = if (shouldBePlaying) Icons.Outlined.Pause
                        else if (binder.player.playbackState == Player.STATE_ENDED) Icons.Outlined.Replay
                        else Icons.Outlined.PlayArrow,
                        contentDescription = if (shouldBePlaying) "Pause" else "Play",
                        tint = Color.White,
                        modifier = Modifier.size(24.dp),
                    )
                }

                LiquidButton(
                    onClick = stopPlayer,
                    backdrop = glassBackdrop,
                    modifier = Modifier.size(32.dp),
                    shape = CircleShape,
                    contentHeight = 32.dp,
                    contentPadding = 0.dp,
                    surfaceColor = Color.White.copy(alpha = 0.025f),
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Clear,
                        contentDescription = "Close player",
                        tint = Color(0xFFAAA3B5),
                        modifier = Modifier.size(16.dp),
                    )
                }
            }

            LinearProgressIndicator(
                progress = {
                    if (positionAndDuration.second.absoluteValue > 0L) {
                        (positionAndDuration.first.toFloat() / positionAndDuration.second.absoluteValue).coerceIn(0f, 1f)
                    } else 0f
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 58.dp, end = 8.dp, top = 5.dp)
                    .height(2.dp)
                    .clip(RoundedCornerShape(10.dp)),
                color = MaterialTheme.colorScheme.primary,
                trackColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.22f)
            )
        }
    }

    val startAction = SwipeAction(
        onSwipe = { binder.player.forceSeekToPrevious() },
        icon = {
            Icon(
                imageVector = Icons.Outlined.SkipPrevious,
                contentDescription = null,
                modifier = Modifier.padding(end = 32.dp),
                tint = MaterialTheme.colorScheme.onPrimaryContainer
            )
        },
        background = MaterialTheme.colorScheme.primaryContainer
    )

    val endAction = SwipeAction(
        onSwipe = { binder.player.forceSeekToNext() },
        icon = {
            Icon(
                imageVector = Icons.Outlined.SkipNext,
                contentDescription = null,
                modifier = Modifier.padding(start = 32.dp),
                tint = MaterialTheme.colorScheme.onPrimaryContainer
            )
        },
        background = MaterialTheme.colorScheme.primaryContainer
    )

    if (miniplayerGesturesEnabled) {
        SwipeableActionsBox(
            startActions = listOf(startAction),
            endActions = listOf(endAction),
            content = miniPlayerContent
        )
    } else {
        Box(content = miniPlayerContent)
    }
}