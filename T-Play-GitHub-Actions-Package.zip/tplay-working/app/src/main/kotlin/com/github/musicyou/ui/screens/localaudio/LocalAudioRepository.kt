package com.github.musicyou.ui.screens.localaudio

import android.content.ContentUris
import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.MediaStore
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import java.io.File
import java.util.Locale

data class LocalAudioTrack(
    val id: String,
    val uri: Uri,
    val title: String,
    val artist: String?,
    val album: String?,
    val durationMs: Long,
    val displayName: String,
    val sizeBytes: Long
) {
    val durationLabel: String
        get() {
            val total = (durationMs / 1000).coerceAtLeast(0)
            return "%d:%02d".format(Locale.getDefault(), total / 60, total % 60)
        }

    fun asMediaItem(): MediaItem = MediaItem.Builder()
        .setMediaId(id)
        .setUri(uri)
        .setCustomCacheKey("local-audio:$id")
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(title)
                .setArtist(artist)
                .setAlbumTitle(album)
                .setExtras(android.os.Bundle().apply {
                    putString("durationText", durationLabel)
                    putBoolean("isLocalAudio", true)
                })
                .build()
        )
        .build()
}

object LocalAudioRepository {
    private val projection = arrayOf(
        MediaStore.Audio.Media._ID,
        MediaStore.Audio.Media.TITLE,
        MediaStore.Audio.Media.ARTIST,
        MediaStore.Audio.Media.ALBUM,
        MediaStore.Audio.Media.DURATION,
        MediaStore.Audio.Media.DISPLAY_NAME,
        MediaStore.Audio.Media.SIZE
    )

    fun queryDeviceAudio(context: Context): List<LocalAudioTrack> {
        val resolver = context.contentResolver
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val result = mutableListOf<LocalAudioTrack>()
        resolver.query(
            collection,
            projection,
            "${MediaStore.Audio.Media.DURATION} > 0",
            null,
            null
        )?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val albumCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME)
            val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE)
            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                val uri = ContentUris.withAppendedId(collection, id)
                result += LocalAudioTrack(
                    id = "device:$id",
                    uri = uri,
                    title = cursor.getString(titleCol)?.takeIf { it.isNotBlank() }
                        ?: cursor.getString(nameCol).orEmpty(),
                    artist = cursor.getString(artistCol)?.takeUnless { it == "<unknown>" },
                    album = cursor.getString(albumCol)?.takeUnless { it == "<unknown>" },
                    durationMs = cursor.getLong(durationCol),
                    displayName = cursor.getString(nameCol).orEmpty(),
                    sizeBytes = cursor.getLong(sizeCol)
                )
            }
        }
        return result.sortedBy { it.title.lowercase(Locale.getDefault()) }
    }

    fun downloadsDirectory(context: Context): File =
        File(context.filesDir, "tplay-downloads").apply { mkdirs() }

    fun savePrivateCopy(context: Context, track: LocalAudioTrack): File {
        val directory = downloadsDirectory(context)
        val originalExtension = track.displayName.substringAfterLast('.', "")
            .lowercase(Locale.ROOT)
            .takeIf { it.matches(Regex("[a-z0-9]{1,8}")) }
        val extension = originalExtension ?: (context.contentResolver.getType(track.uri)
            ?.substringAfter('/')?.substringBefore(';')?.takeIf { it.matches(Regex("[a-zA-Z0-9.+-]{1,12}")) }
            ?: "audio")
        val safeTitle = track.title
            .replace(Regex("[^\\p{L}\\p{N}._ -]"), "")
            .trim()
            .replace(Regex("\\s+"), "_")
            .take(64)
            .ifBlank { "TPlay_Audio" }
        val target = File(directory, "$safeTitle-${System.currentTimeMillis()}.$extension")
        val temp = File(directory, "${target.name}.part")
        try {
            val input = context.contentResolver.openInputStream(track.uri)
                ?: error("Cannot open selected audio")
            input.use { source ->
                temp.outputStream().buffered().use { sink -> source.copyTo(sink) }
            }
            if (!temp.renameTo(target)) {
                temp.copyTo(target, overwrite = true)
                temp.delete()
            }
            return target
        } catch (error: Exception) {
            temp.delete()
            target.delete()
            throw error
        }
    }

    fun queryPrivateDownloads(context: Context): List<LocalAudioTrack> {
        val directory = downloadsDirectory(context)
        return directory.listFiles()
            ?.filter { it.isFile && it.extension.lowercase(Locale.ROOT) in setOf(
                "mp3", "m4a", "aac", "wav", "flac", "ogg", "opus", "3gp", "mp4", "webm", "audio"
            ) }
            ?.sortedBy { it.name.lowercase(Locale.ROOT) }
            ?.map { file ->
                val metadata = MediaMetadataRetriever()
                var title = file.nameWithoutExtension
                var artist: String? = null
                var album: String? = null
                var duration = 0L
                try {
                    metadata.setDataSource(file.absolutePath)
                    title = metadata.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)
                        ?.takeIf { it.isNotBlank() } ?: file.nameWithoutExtension
                    artist = metadata.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST)
                    album = metadata.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM)
                    duration = metadata.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                        ?.toLongOrNull() ?: 0L
                } catch (_: Exception) {
                    // Keep safe filename-based metadata when a codec cannot read tags.
                } finally {
                    runCatching { metadata.release() }
                }
                LocalAudioTrack(
                    id = "offline:${file.name}",
                    uri = Uri.fromFile(file),
                    title = title,
                    artist = artist,
                    album = album,
                    durationMs = duration,
                    displayName = file.name,
                    sizeBytes = file.length()
                )
            } ?: emptyList()
    }

    fun deletePrivateCopy(context: Context, track: LocalAudioTrack): Boolean {
        val file = track.uri.path?.let(::File) ?: return false
        val root = downloadsDirectory(context).canonicalFile
        val candidate = file.canonicalFile
        if (candidate.parentFile != root) return false
        return candidate.delete()
    }
}
