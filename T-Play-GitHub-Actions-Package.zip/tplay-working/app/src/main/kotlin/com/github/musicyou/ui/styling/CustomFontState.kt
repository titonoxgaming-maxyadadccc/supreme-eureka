package com.github.musicyou.ui.styling

import android.graphics.Typeface
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.text.font.FontFamily

/** Runtime font family loaded from a user-selected local TTF/OTF file. */
object CustomFontState {
    var fontFamily: FontFamily? by mutableStateOf(null)
        private set

    fun load(path: String) {
        fontFamily = if (path.isBlank()) null else runCatching {
            FontFamily(Typeface.createFromFile(path))
        }.getOrNull()
    }
}
