package com.github.musicyou.ui.styling

import android.os.Build
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.getValue
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.compositeOver
import com.github.musicyou.enums.AlbumAccentMode
import com.github.musicyou.ui.styling.AlbumArtworkPalette
import com.github.musicyou.ui.styling.AlbumAccentModeState
import com.github.musicyou.utils.albumAccentModeKey
import com.github.musicyou.utils.customFontPathKey
import com.github.musicyou.utils.rememberPreference

private val lightScheme = lightColorScheme(
    primary = primaryLight,
    onPrimary = onPrimaryLight,
    primaryContainer = primaryContainerLight,
    onPrimaryContainer = onPrimaryContainerLight,
    secondary = secondaryLight,
    onSecondary = onSecondaryLight,
    secondaryContainer = secondaryContainerLight,
    onSecondaryContainer = onSecondaryContainerLight,
    tertiary = tertiaryLight,
    onTertiary = onTertiaryLight,
    tertiaryContainer = tertiaryContainerLight,
    onTertiaryContainer = onTertiaryContainerLight,
    error = errorLight,
    onError = onErrorLight,
    errorContainer = errorContainerLight,
    onErrorContainer = onErrorContainerLight,
    background = backgroundLight,
    onBackground = onBackgroundLight,
    surface = surfaceLight,
    onSurface = onSurfaceLight,
    surfaceVariant = surfaceVariantLight,
    onSurfaceVariant = onSurfaceVariantLight,
    outline = outlineLight,
    outlineVariant = outlineVariantLight,
    scrim = scrimLight,
    inverseSurface = inverseSurfaceLight,
    inverseOnSurface = inverseOnSurfaceLight,
    inversePrimary = inversePrimaryLight,
    surfaceDim = surfaceDimLight,
    surfaceBright = surfaceBrightLight,
    surfaceContainerLowest = surfaceContainerLowestLight,
    surfaceContainerLow = surfaceContainerLowLight,
    surfaceContainer = surfaceContainerLight,
    surfaceContainerHigh = surfaceContainerHighLight,
    surfaceContainerHighest = surfaceContainerHighestLight,
)

private val darkScheme = darkColorScheme(
    primary = primaryDark,
    onPrimary = onPrimaryDark,
    primaryContainer = primaryContainerDark,
    onPrimaryContainer = onPrimaryContainerDark,
    secondary = secondaryDark,
    onSecondary = onSecondaryDark,
    secondaryContainer = secondaryContainerDark,
    onSecondaryContainer = onSecondaryContainerDark,
    tertiary = tertiaryDark,
    onTertiary = onTertiaryDark,
    tertiaryContainer = tertiaryContainerDark,
    onTertiaryContainer = onTertiaryContainerDark,
    error = errorDark,
    onError = onErrorDark,
    errorContainer = errorContainerDark,
    onErrorContainer = onErrorContainerDark,
    background = backgroundDark,
    onBackground = onBackgroundDark,
    surface = surfaceDark,
    onSurface = onSurfaceDark,
    surfaceVariant = surfaceVariantDark,
    onSurfaceVariant = onSurfaceVariantDark,
    outline = outlineDark,
    outlineVariant = outlineVariantDark,
    scrim = scrimDark,
    inverseSurface = inverseSurfaceDark,
    inverseOnSurface = inverseOnSurfaceDark,
    inversePrimary = inversePrimaryDark,
    surfaceDim = surfaceDimDark,
    surfaceBright = surfaceBrightDark,
    surfaceContainerLowest = surfaceContainerLowestDark,
    surfaceContainerLow = surfaceContainerLowDark,
    surfaceContainer = surfaceContainerDark,
    surfaceContainerHigh = surfaceContainerHighDark,
    surfaceContainerHighest = surfaceContainerHighestDark,
)

@Composable
fun AppTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    val persistedAccentMode by rememberPreference(albumAccentModeKey, AlbumAccentMode.Artwork)
    val customFontPath by rememberPreference(customFontPathKey, "")
    LaunchedEffect(customFontPath) { CustomFontState.load(customFontPath) }
    val appTypography = remember(CustomFontState.fontFamily) {
        CustomFontState.fontFamily?.let(::typographyWithFontFamily) ?: Typography
    }
    LaunchedEffect(Unit) {
        if (!AlbumAccentModeState.initialized) {
            AlbumAccentModeState.mode = persistedAccentMode
            AlbumAccentModeState.initialized = true
        }
    }
    val accentMode = AlbumAccentModeState.mode
    val artworkAccent = AlbumArtworkPalette.accent
    val selectedAccent = when (accentMode) {
        AlbumAccentMode.Artwork -> artworkAccent
        AlbumAccentMode.Violet -> Color(0xFFB9A4FF)
        AlbumAccentMode.Blue -> Color(0xFF72B7FF)
        AlbumAccentMode.Rose -> Color(0xFFFF829F)
        AlbumAccentMode.Emerald -> Color(0xFF65D5B1)
    }

    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }

        darkTheme -> darkScheme.copy(
            primary = selectedAccent,
            onPrimary = if (selectedAccent.red * 0.299f + selectedAccent.green * 0.587f + selectedAccent.blue * 0.114f > 0.62f) Color.Black else Color.White,
            primaryContainer = selectedAccent.copy(alpha = 0.24f).compositeOver(Color(0xFF191622)),
            onPrimaryContainer = Color(0xFFF7F4FF),
            secondary = selectedAccent,
            secondaryContainer = selectedAccent.copy(alpha = 0.16f).compositeOver(Color(0xFF191622)),
            tertiary = selectedAccent,
            surface = selectedAccent.copy(alpha = 0.025f).compositeOver(surfaceDark),
            surfaceVariant = selectedAccent.copy(alpha = 0.07f).compositeOver(surfaceVariantDark),
            surfaceContainerLow = selectedAccent.copy(alpha = 0.055f).compositeOver(surfaceContainerLowDark),
            surfaceContainer = selectedAccent.copy(alpha = 0.075f).compositeOver(surfaceContainerDark),
            surfaceContainerHigh = selectedAccent.copy(alpha = 0.095f).compositeOver(surfaceContainerHighDark),
            outline = selectedAccent.copy(alpha = 0.62f),
            outlineVariant = selectedAccent.copy(alpha = 0.24f)
        )
        else -> lightScheme.copy(primary = selectedAccent, secondary = selectedAccent, tertiary = selectedAccent)
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = appTypography,
        content = content
    )
}