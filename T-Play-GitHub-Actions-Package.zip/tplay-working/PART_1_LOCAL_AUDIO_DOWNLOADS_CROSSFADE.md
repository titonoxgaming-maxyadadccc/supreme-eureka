# TITONOX PLAYER 1.4.0 — Part 1 implementation

## Included in this source update

### Local device audio
- Requests `READ_MEDIA_AUDIO` on Android 13+ and `READ_EXTERNAL_STORAGE` on Android 12L and earlier.
- Lists audio tracks indexed by Android MediaStore.
- Tap a row to play through the existing Media3 player queue.
- Long-press a local device track to begin copying it into the app's private storage.

### T Play Downloads
- Copies are stored in `filesDir/tplay-downloads`.
- These copies are not written to the public Downloads directory.
- The Downloads screen plays saved copies offline and lets the user remove only the app-private copy.
- Removing a T Play copy does not delete the original device file.

### Crossfade
- Enabled by default.
- Starts loading the next queue item before the current one ends.
- Uses two Media3 player instances and an equal-power volume curve.
- Default overlap is 4 seconds; Settings allows 2–6 seconds and OFF.
- Cancels safely on pause, seek, manual skip, queue edit, shuffle/repeat changes, or turning the setting off.
- Speed/pitch and supported Bass Boost, Reverb and Equalizer settings are mirrored to the secondary player.

## Important source limitation
YouTube Music items remain online streams. This app does not export YouTube streams into MP3 files or copy protected stream data into private storage. The in-app private download flow currently copies audio files that the user has selected from the device library and that Android permits the app to read.

## Validation status
- XML resources and manifest parse successfully.
- Resource-name duplicate check passed.
- New Local Music and Downloads routes are wired.
- Source-level checks passed for permission declarations, private storage path, local URI data-source support and crossfade preference/engine references.
- Full Kotlin/Gradle compilation and physical-device playback tests are still required. The current build environment could not resolve `services.gradle.org` to download the configured Gradle distribution.
